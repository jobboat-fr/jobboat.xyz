/**
 * JobBoat Auto-Fill — Form Field Detector
 *
 * Generic detector that identifies common application form fields on any
 * job portal. Platform-specific adapters can override detection for known sites.
 *
 * Exposed as window.__jobboatDetector for use by filler.js and platform adapters.
 */

(function () {
  'use strict';

  // ── Field type definitions ───────────────────────────────────────────

  const FIELD_PATTERNS = {
    firstName: {
      names: ['first_name', 'firstname', 'first-name', 'prenom', 'prénom', 'given_name', 'givenname', 'fname'],
      labels: [/pr[ée]nom/i, /first\s*name/i, /given\s*name/i],
      placeholders: [/pr[ée]nom/i, /first\s*name/i],
      autocomplete: ['given-name'],
    },
    lastName: {
      names: ['last_name', 'lastname', 'last-name', 'nom', 'family_name', 'familyname', 'surname', 'lname'],
      labels: [/nom\s*(de famille)?$/i, /last\s*name/i, /family\s*name/i, /surname/i],
      placeholders: [/nom(\s|$)/i, /last\s*name/i],
      autocomplete: ['family-name'],
    },
    fullName: {
      names: ['name', 'full_name', 'fullname', 'full-name', 'applicant_name', 'candidate_name', 'nom_complet'],
      labels: [/^nom\s*(complet|et pr[ée]nom)?$/i, /full\s*name/i, /^name$/i, /your\s*name/i, /nom\s*&?\s*pr[ée]nom/i],
      placeholders: [/nom\s*(complet)?/i, /full\s*name/i, /votre\s*nom/i],
      autocomplete: ['name'],
    },
    email: {
      names: ['email', 'e-mail', 'email_address', 'emailaddress', 'courriel', 'mail'],
      labels: [/e[\-\s]?mail/i, /courriel/i, /adresse\s*[ée]lectronique/i],
      placeholders: [/e[\-\s]?mail/i, /courriel/i],
      autocomplete: ['email'],
      types: ['email'],
    },
    phone: {
      names: ['phone', 'telephone', 'tel', 'phone_number', 'phonenumber', 'mobile', 'portable', 'numero'],
      labels: [/t[ée]l[ée]phone/i, /phone/i, /mobile/i, /portable/i, /num[ée]ro/i],
      placeholders: [/t[ée]l[ée]phone/i, /phone/i, /num[ée]ro/i],
      autocomplete: ['tel'],
      types: ['tel'],
    },
    city: {
      names: ['city', 'ville', 'location', 'localisation', 'lieu'],
      labels: [/ville/i, /city/i, /localisation/i, /lieu/i, /location/i],
      placeholders: [/ville/i, /city/i],
      autocomplete: ['address-level2'],
    },
    linkedin: {
      names: ['linkedin', 'linkedin_url', 'linkedin_profile', 'linkedin-url'],
      labels: [/linkedin/i, /profil\s*linkedin/i],
      placeholders: [/linkedin/i],
    },
    portfolio: {
      names: ['portfolio', 'website', 'site_web', 'site-web', 'url', 'personal_website'],
      labels: [/portfolio/i, /site\s*(web|personnel)/i, /website/i],
      placeholders: [/portfolio/i, /site\s*web/i, /website/i],
      autocomplete: ['url'],
      types: ['url'],
    },
    coverLetter: {
      names: ['cover_letter', 'coverletter', 'cover-letter', 'lettre_motivation', 'lettre-motivation', 'motivation', 'message'],
      labels: [/lettre\s*(de)?\s*motivation/i, /cover\s*letter/i, /message/i, /motivations?$/i, /pourquoi\s*(postulez|candidatez)/i],
      placeholders: [/lettre\s*(de)?\s*motivation/i, /cover\s*letter/i, /motivations?/i],
    },
    salary: {
      names: ['salary', 'salary_expectation', 'salaire', 'remuneration', 'pretention'],
      labels: [/salaire/i, /salary/i, /r[ée]mun[ée]ration/i, /pr[ée]tention/i],
      placeholders: [/salaire/i, /salary/i, /pr[ée]tention/i],
    },
    availability: {
      names: ['availability', 'disponibilite', 'disponibilité', 'start_date', 'startdate'],
      labels: [/disponibilit[ée]/i, /availability/i, /date\s*de\s*d[ée]but/i, /start\s*date/i],
      placeholders: [/disponibilit[ée]/i, /availability/i],
    },
    resume: {
      names: ['resume', 'cv', 'curriculum', 'file', 'attachment', 'document', 'fichier'],
      labels: [/cv/i, /r[ée]sum[ée]/i, /curriculum/i, /fichier/i, /t[ée]l[ée]charger/i, /upload/i, /joindre/i],
      types: ['file'],
    },
  };

  // ── Utilities ────────────────────────────────────────────────────────

  function getFieldAttribute(el, attr) {
    return (el.getAttribute(attr) || '').trim().toLowerCase();
  }

  function getAssociatedLabel(el) {
    // Check explicit label via for attribute
    const id = el.id;
    if (id) {
      const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (label) return label.textContent.trim();
    }
    // Check parent label
    const parentLabel = el.closest('label');
    if (parentLabel) return parentLabel.textContent.trim();
    // Check aria-label
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) return ariaLabel.trim();
    // Check aria-labelledby
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const labelEl = document.getElementById(labelledBy);
      if (labelEl) return labelEl.textContent.trim();
    }
    // Check preceding sibling or parent text
    const prev = el.previousElementSibling;
    if (prev && (prev.tagName === 'LABEL' || prev.tagName === 'SPAN' || prev.tagName === 'P')) {
      return prev.textContent.trim();
    }
    return '';
  }

  function matchesPattern(value, patterns) {
    if (!value) return false;
    return patterns.some((p) => {
      if (p instanceof RegExp) return p.test(value);
      return value === p;
    });
  }

  // ── Core detection ───────────────────────────────────────────────────

  function identifyField(el) {
    const tag = el.tagName.toLowerCase();
    if (tag !== 'input' && tag !== 'textarea' && tag !== 'select' && !el.isContentEditable) return null;

    const name = getFieldAttribute(el, 'name');
    const id = getFieldAttribute(el, 'id');
    const type = getFieldAttribute(el, 'type') || 'text';
    const placeholder = getFieldAttribute(el, 'placeholder');
    const autocomplete = getFieldAttribute(el, 'autocomplete');
    const label = getAssociatedLabel(el);
    const dataTestId = getFieldAttribute(el, 'data-testid') || getFieldAttribute(el, 'data-test');

    // Skip hidden, submit, and button fields
    if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'reset') return null;
    if (el.offsetParent === null && type !== 'file') return null; // not visible

    const allNames = [name, id, dataTestId].filter(Boolean);

    for (const [fieldType, patterns] of Object.entries(FIELD_PATTERNS)) {
      // Check name/id match
      if (patterns.names && allNames.some((n) => patterns.names.includes(n))) {
        return { type: fieldType, element: el, confidence: 0.95, matchedBy: 'name' };
      }

      // Check autocomplete
      if (patterns.autocomplete && autocomplete && patterns.autocomplete.includes(autocomplete)) {
        return { type: fieldType, element: el, confidence: 0.9, matchedBy: 'autocomplete' };
      }

      // Check input type
      if (patterns.types && patterns.types.includes(type)) {
        return { type: fieldType, element: el, confidence: 0.85, matchedBy: 'type' };
      }

      // Check label text
      if (patterns.labels && label && matchesPattern(label, patterns.labels)) {
        return { type: fieldType, element: el, confidence: 0.8, matchedBy: 'label' };
      }

      // Check placeholder
      if (patterns.placeholders && placeholder && matchesPattern(placeholder, patterns.placeholders)) {
        return { type: fieldType, element: el, confidence: 0.7, matchedBy: 'placeholder' };
      }
    }

    return null;
  }

  function detectFormFields(root = document) {
    const inputs = root.querySelectorAll('input, textarea, select, [contenteditable="true"]');
    const detected = [];
    const seen = new Set();

    for (const el of inputs) {
      const field = identifyField(el);
      if (field && !seen.has(field.type)) {
        detected.push(field);
        seen.add(field.type);
      }
    }

    return detected;
  }

  function detectCurrentPlatform() {
    const host = window.location.hostname.toLowerCase();
    if (host.includes('indeed')) return 'indeed';
    if (host.includes('linkedin')) return 'linkedin';
    if (host.includes('welcometothejungle')) return 'wttj';
    if (host.includes('hellowork')) return 'hellowork';
    if (host.includes('glassdoor')) return 'glassdoor';
    if (host.includes('monster')) return 'monster';
    if (host.includes('apec')) return 'apec';
    if (host.includes('francetravail') || host.includes('pole-emploi')) return 'francetravail';
    if (host.includes('cadremploi')) return 'cadremploi';
    return 'generic';
  }

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    const title = document.title.toLowerCase();
    const keywords = ['apply', 'postuler', 'candidat', 'application', 'candidature', 'soumettre'];
    return keywords.some((kw) => url.includes(kw) || title.includes(kw));
  }

  // ── DOM serialization for AI detection ──────────────────────────────

  function getNearbyText(el, maxLen) {
    maxLen = maxLen || 60;
    const parent = el.closest('div, fieldset, section, li, td, form');
    if (!parent) return '';
    const clone = parent.cloneNode(true);
    // Remove the input itself and any other inputs to keep text only
    clone.querySelectorAll('input, textarea, select, button, script, style').forEach(n => n.remove());
    return (clone.textContent || '').replace(/\s+/g, ' ').trim().slice(0, maxLen);
  }

  function serializeFormElements(root) {
    root = root || document;
    const inputs = root.querySelectorAll('input, textarea, select, [contenteditable="true"]');
    const serialized = [];

    for (const el of inputs) {
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute('type') || 'text').toLowerCase();

      // Skip hidden, submit, button fields
      if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'reset') continue;
      if (el.offsetParent === null && type !== 'file') continue;

      serialized.push({
        tag: tag,
        type: tag === 'input' ? type : tag,
        name: (el.getAttribute('name') || '').toLowerCase() || undefined,
        id: (el.getAttribute('id') || '').toLowerCase() || undefined,
        placeholder: (el.getAttribute('placeholder') || '').toLowerCase() || undefined,
        autocomplete: (el.getAttribute('autocomplete') || '').toLowerCase() || undefined,
        ariaLabel: (el.getAttribute('aria-label') || '') || undefined,
        label: getAssociatedLabel(el) || undefined,
        nearbyText: getNearbyText(el) || undefined,
      });
    }

    return serialized;
  }

  // ── Export ────────────────────────────────────────────────────────────

  window.__jobboatDetector = {
    detectFormFields,
    detectCurrentPlatform,
    isApplicationPage,
    identifyField,
    serializeFormElements,
    FIELD_PATTERNS,
  };
})();
