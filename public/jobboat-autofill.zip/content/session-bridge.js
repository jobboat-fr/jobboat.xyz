/**
 * Session Bridge — runs on jobboat.xyz / demo.jobboat.xyz / *.vercel.app
 *
 * Reads the Supabase session from localStorage and forwards it to the
 * extension background service worker so content scripts on job portals
 * can authenticate API calls without the user logging in again.
 */

(function sessionBridge() {
  const SUPABASE_KEY_PREFIX = 'sb-';
  const SUPABASE_KEY_SUFFIX = '-auth-token';

  function findSupabaseSession() {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(SUPABASE_KEY_PREFIX) && key.endsWith(SUPABASE_KEY_SUFFIX)) {
        try {
          const raw = localStorage.getItem(key);
          const parsed = JSON.parse(raw);
          if (parsed && parsed.access_token) return parsed;
          // Supabase v2 stores inside a nested structure
          if (parsed && parsed.currentSession && parsed.currentSession.access_token) {
            return parsed.currentSession;
          }
        } catch (_) {}
      }
    }
    return null;
  }

  function sendSession() {
    const session = findSupabaseSession();
    if (session && session.access_token) {
      chrome.runtime.sendMessage({
        type: 'SESSION_UPDATE',
        payload: {
          access_token: session.access_token,
          refresh_token: session.refresh_token || null,
          user: session.user || null,
          expires_at: session.expires_at || null,
        },
      });
    }
  }

  // Send immediately on page load
  sendSession();

  // Re-check every 30 seconds (covers token refresh)
  setInterval(sendSession, 30000);

  // Listen for storage events (login/logout in another tab)
  window.addEventListener('storage', (e) => {
    if (e.key && e.key.startsWith(SUPABASE_KEY_PREFIX)) {
      if (e.newValue) {
        sendSession();
      } else {
        chrome.runtime.sendMessage({ type: 'SESSION_CLEAR' });
      }
    }
  });
})();
