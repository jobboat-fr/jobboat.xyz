/**
 * JobBoat Auto-Fill — Form Filler Engine
 *
 * Core auto-fill logic:
 *  1. Detects form fields via detector.js
 *  2. Fetches cached profile from background service worker
 *  3. Fills fields with profile data
 *  4. Shows a floating "Auto-Fill" button overlay
 *  5. Tracks application via backend
 */

(function () {
  'use strict';

  const OVERLAY_ID = 'jobboat-autofill-overlay';
  const FILLED_ATTR = 'data-jobboat-filled';
  let profileCache = null;
  let isOverlayVisible = false;
  let aiMappingsCache = null;
  let aiDetectionInProgress = false;

  // ── Profile fetching ─────────────────────────────────────────────────

  function getProfile() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_PROFILE' }, (response) => {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        resolve(response?.profile || null);
      });
    });
  }

  // ── AI-powered field detection ─────────────────────────────────────

  function requestAiDetection(elements) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: 'AI_DETECT_FIELDS', payload: { elements } },
        (response) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, mappings: [] });
            return;
          }
          resolve(response || { success: false, mappings: [] });
        }
      );
    });
  }

  async function aiDetectAndMap() {
    if (aiDetectionInProgress) return null;
    if (!window.__jobboatDetector?.serializeFormElements) return null;

    aiDetectionInProgress = true;
    try {
      const elements = window.__jobboatDetector.serializeFormElements();
      if (!elements.length) return null;

      const result = await requestAiDetection(elements);
      if (!result.success || !result.mappings?.length) return null;

      // Map AI results back to actual DOM elements
      const inputs = document.querySelectorAll('input, textarea, select, [contenteditable="true"]');
      const visibleInputs = [];
      for (const el of inputs) {
        const type = (el.getAttribute('type') || 'text').toLowerCase();
        if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'reset') continue;
        if (el.offsetParent === null && type !== 'file') continue;
        visibleInputs.push(el);
      }

      const aiFields = [];
      const seen = new Set();
      for (const m of result.mappings) {
        if (m.index < visibleInputs.length && !seen.has(m.fieldType)) {
          aiFields.push({
            type: m.fieldType,
            element: visibleInputs[m.index],
            confidence: m.confidence || 0.85,
            matchedBy: 'ai',
          });
          seen.add(m.fieldType);
        }
      }

      aiMappingsCache = aiFields;
      return aiFields;
    } catch (_e) {
      return null;
    } finally {
      aiDetectionInProgress = false;
    }
  }

  // ── Value setters (React-compatible) ─────────────────────────────────

  function setNativeValue(el, value) {
    if (!el || !value) return false;

    const tag = el.tagName.toLowerCase();

    if (el.isContentEditable) {
      el.textContent = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }

    // React overrides the native value setter — we need to call it directly
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      tag === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
      'value'
    )?.set;

    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(el, value);
    } else {
      el.value = value;
    }

    // Dispatch events to trigger React/Vue/Angular change detection
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));

    return true;
  }

  // ── Profile → Field mapping ──────────────────────────────────────────

  function getValueForField(fieldType, profile) {
    switch (fieldType) {
      case 'firstName': {
        const parts = (profile.name || '').split(/\s+/);
        return parts[0] || '';
      }
      case 'lastName': {
        const parts = (profile.name || '').split(/\s+/);
        return parts.slice(1).join(' ') || '';
      }
      case 'fullName':
        return profile.name || '';
      case 'email':
        return profile.email || '';
      case 'phone':
        return profile.phone || '';
      case 'city':
        return profile.city || '';
      case 'linkedin':
        return profile.linkedin_url || '';
      case 'portfolio':
        return profile.portfolio_url || '';
      case 'coverLetter':
        return ''; // Generated per-job, not from profile
      case 'salary':
        return profile.salary_expectation || '';
      case 'availability':
        return profile.availability || '';
      default:
        return '';
    }
  }

  // ── Fill logic ───────────────────────────────────────────────────────

  function fillFields(fields, profile) {
    let filledCount = 0;

    for (const field of fields) {
      if (field.element.getAttribute(FILLED_ATTR)) continue;
      if (field.type === 'resume') continue; // File inputs can't be auto-filled

      const value = getValueForField(field.type, profile);
      if (!value) continue;

      // Don't overwrite existing values unless empty
      const current = field.element.value || field.element.textContent || '';
      if (current.trim() && current.trim() !== value) continue;

      if (setNativeValue(field.element, value)) {
        field.element.setAttribute(FILLED_ATTR, 'true');
        field.element.style.outline = '2px solid #3b82f6';
        setTimeout(() => {
          field.element.style.outline = '';
        }, 2000);
        filledCount++;
      }
    }

    return filledCount;
  }

  // ── Platform adapter hooks ───────────────────────────────────────────

  function getPlatformAdapter() {
    const platform = window.__jobboatDetector?.detectCurrentPlatform();
    switch (platform) {
      case 'indeed': return window.__jobboatIndeed || null;
      case 'linkedin': return window.__jobboatLinkedin || null;
      case 'wttj': return window.__jobboatWttj || null;
      case 'hellowork': return window.__jobboatHellowork || null;
      case 'apec': return window.__jobboatApec || null;
      case 'monster': return window.__jobboatMonster || null;
      case 'cadremploi': return window.__jobboatCadremploi || null;
      case 'francetravail': return window.__jobboatFrancetravail || null;
      case 'glassdoor': return window.__jobboatGlassdoor || null;
      default: return null;
    }
  }

  // ── Overlay UI ───────────────────────────────────────────────────────

  function createOverlay(fieldCount) {
    let overlay = document.getElementById(OVERLAY_ID);
    if (overlay) {
      overlay.remove();
    }

    overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.innerHTML = `
      <div class="jobboat-af-header">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
        </svg>
        <span>JobBoat Auto-Fill</span>
        <button class="jobboat-af-close" title="Fermer">&times;</button>
      </div>
      <div class="jobboat-af-body">
        <p class="jobboat-af-status">${fieldCount} champ${fieldCount > 1 ? 's' : ''} d${fieldCount > 1 ? 'e' : 'u'} formulaire d&eacute;tect&eacute;${fieldCount > 1 ? 's' : ''}</p>
        <button class="jobboat-af-btn jobboat-af-fill">Remplir automatiquement</button>
        <button class="jobboat-af-btn jobboat-af-secondary jobboat-af-refresh">Actualiser</button>
      </div>
      <div class="jobboat-af-footer">
        <span class="jobboat-af-user"></span>
      </div>
    `;

    document.body.appendChild(overlay);
    isOverlayVisible = true;

    // Close button
    overlay.querySelector('.jobboat-af-close').addEventListener('click', () => {
      overlay.style.display = 'none';
      isOverlayVisible = false;
    });

    // Fill button
    overlay.querySelector('.jobboat-af-fill').addEventListener('click', async () => {
      const btn = overlay.querySelector('.jobboat-af-fill');
      btn.textContent = 'Remplissage...';
      btn.disabled = true;

      const profile = profileCache || (await getProfile());
      if (!profile) {
        btn.textContent = 'Connectez-vous sur JobBoat';
        btn.disabled = false;
        return;
      }

      profileCache = profile;

      // Telemetry tracking: start timer, record method + fields_found
      const platform = window.__jobboatDetector?.detectCurrentPlatform() || 'generic';
      const startMs = Date.now();
      let method = 'heuristic';
      let adapterUsed = false;
      let aiUsed = false;
      let fieldsFound = 0;
      let errorMessage = null;

      // Try platform-specific adapter first
      const adapter = getPlatformAdapter();
      let filled = 0;
      try {
        if (adapter && typeof adapter.fill === 'function') {
          filled = await adapter.fill(profile);
          if (filled > 0) {
            method = 'adapter';
            adapterUsed = true;
            fieldsFound = filled;
          }
        }

        // Fall back to generic heuristic detection
        if (filled === 0) {
          const fields = window.__jobboatDetector.detectFormFields();
          fieldsFound = fields.length;
          filled = fillFields(fields, profile);

          // If heuristic found < 3 fields, try AI-powered detection
          if (filled < 3) {
            btn.textContent = 'Analyse IA en cours...';
            const aiFields = await aiDetectAndMap();
            if (aiFields && aiFields.length > filled) {
              const aiFilled = fillFields(aiFields, profile);
              filled += aiFilled;
              fieldsFound = Math.max(fieldsFound, aiFields.length);
              aiUsed = true;
              method = 'ai';
            }
          }
        }
      } catch (err) {
        errorMessage = err?.message || String(err);
      }

      const durationMs = Date.now() - startMs;

      // Always send telemetry, even on failure — this is our "measured precision" source.
      sendTelemetry({
        platform,
        hostname: window.location.hostname,
        method,
        fields_found: fieldsFound,
        fields_filled: filled,
        duration_ms: durationMs,
        success: filled >= 3,
        ai_used: aiUsed,
        adapter_used: adapterUsed,
        error_message: errorMessage,
      });

      const status = overlay.querySelector('.jobboat-af-status');
      if (filled > 0) {
        const aiSuffix = aiUsed ? ' (IA)' : (adapterUsed ? ' (adapter)' : '');
        status.textContent = `${filled} champ${filled > 1 ? 's' : ''} rempli${filled > 1 ? 's' : ''}${aiSuffix}`;
        btn.textContent = aiUsed ? 'Rempli via IA !' : 'Rempli !';
        btn.style.background = '#22c55e';
        trackFill(filled);

        // If < 3 fields filled, show the "Aide-moi" fallback even on partial success
        if (filled < 3) showHelpMeFallback(overlay, profile, platform);
      } else {
        status.textContent = 'Aucun champ reconnu sur cette page';
        btn.textContent = 'Remplir automatiquement';
        showHelpMeFallback(overlay, profile, platform);
      }
      btn.disabled = false;
    });

    // Refresh button
    overlay.querySelector('.jobboat-af-refresh').addEventListener('click', () => {
      initDetection();
    });

    // Show user email
    if (profileCache?.email) {
      overlay.querySelector('.jobboat-af-user').textContent = profileCache.email;
    }

    // Make draggable
    makeDraggable(overlay);
  }

  function makeDraggable(el) {
    const header = el.querySelector('.jobboat-af-header');
    let isDragging = false;
    let startX, startY, origX, origY;

    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('.jobboat-af-close')) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      origX = rect.left;
      origY = rect.top;
      header.style.cursor = 'grabbing';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      el.style.left = `${origX + dx}px`;
      el.style.top = `${origY + dy}px`;
      el.style.right = 'auto';
      el.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', () => {
      isDragging = false;
      header.style.cursor = 'grab';
    });
  }

  // ── Tracking ─────────────────────────────────────────────────────────

  function trackFill(filledCount) {
    const platform = window.__jobboatDetector?.detectCurrentPlatform() || 'unknown';
    chrome.runtime.sendMessage({
      type: 'TRACK_APPLICATION',
      payload: {
        platform,
        url: window.location.href,
        title: document.title,
        fields_filled: filledCount,
        timestamp: new Date().toISOString(),
      },
    });
  }

  function sendTelemetry(payload) {
    try {
      chrome.runtime.sendMessage({
        type: 'TRACK_AUTOFILL_TELEMETRY',
        payload,
      });
    } catch (_e) { /* telemetry is best-effort */ }
  }

  // ── Fallback UX: "Aide-moi" when detection was partial ──────────────
  // Lets the user point at the field that asks for email, name, etc.
  // Feeds the data as user_assisted telemetry — turns failure into training data.
  function showHelpMeFallback(overlay, profile, platform) {
    // Don't show twice
    if (overlay.querySelector('.jobboat-af-helpme')) return;

    const body = overlay.querySelector('.jobboat-af-body');
    if (!body) return;

    const container = document.createElement('div');
    container.className = 'jobboat-af-helpme';
    container.innerHTML = `
      <div class="jobboat-af-helpme-msg">
        Je n'ai pas reconnu tous les champs. Aide-moi&nbsp;:
      </div>
      <button class="jobboat-af-btn jobboat-af-secondary jobboat-af-helpme-btn">
        Montrer le champ email
      </button>
    `;
    body.appendChild(container);

    let pickingFor = null;
    const helpBtn = container.querySelector('.jobboat-af-helpme-btn');

    // Sequence of field types to ask the user about
    const askSequence = ['email', 'phone', 'firstName', 'lastName', 'city'];
    let askIdx = 0;

    const labelMap = {
      email: 'email',
      phone: 'téléphone',
      firstName: 'prénom',
      lastName: 'nom',
      city: 'ville',
    };

    function updateButtonLabel() {
      if (askIdx >= askSequence.length) {
        helpBtn.textContent = 'Merci ! Tous les champs aidés.';
        helpBtn.disabled = true;
        return;
      }
      const next = askSequence[askIdx];
      helpBtn.textContent = `Montrer le champ ${labelMap[next] || next}`;
    }

    helpBtn.addEventListener('click', () => {
      if (askIdx >= askSequence.length) return;
      pickingFor = askSequence[askIdx];
      helpBtn.textContent = `Clique sur le champ "${labelMap[pickingFor]}" dans la page...`;
      helpBtn.disabled = true;
      document.body.style.cursor = 'crosshair';
      setTimeout(() => { document.addEventListener('click', pickHandler, { once: true, capture: true }); }, 50);
    });

    function pickHandler(ev) {
      document.body.style.cursor = '';
      const target = ev.target.closest('input, textarea, select, [contenteditable="true"]');
      helpBtn.disabled = false;
      if (!target) {
        helpBtn.textContent = 'Pas un champ valide. Réessaie.';
        updateButtonLabel();
        return;
      }
      ev.preventDefault();
      ev.stopPropagation();

      // Fill it
      const value = getValueForField(pickingFor, profile);
      if (value) {
        setNativeValue(target, value);
        target.style.outline = '2px solid #22c55e';
        setTimeout(() => { target.style.outline = ''; }, 2000);

        // Telemetry: user-assisted mapping is gold training data
        sendTelemetry({
          platform,
          hostname: window.location.hostname,
          method: 'user_assisted',
          fields_found: 1,
          fields_filled: 1,
          duration_ms: 0,
          success: true,
          ai_used: false,
          adapter_used: false,
        });
      }

      askIdx++;
      updateButtonLabel();
    }
  }

  // ── Init ─────────────────────────────────────────────────────────────

  async function initDetection() {
    // Wait for detector to be loaded
    if (!window.__jobboatDetector) {
      setTimeout(initDetection, 500);
      return;
    }

    const profile = await getProfile();
    profileCache = profile;

    // Detect platform
    const platform = window.__jobboatDetector.detectCurrentPlatform();

    // Check if this looks like an application page
    const adapter = getPlatformAdapter();
    const isAppPage = adapter
      ? (typeof adapter.isApplicationPage === 'function' ? adapter.isApplicationPage() : true)
      : window.__jobboatDetector.isApplicationPage();

    if (!isAppPage) return; // Not an application page, don't show overlay

    // Detect fields
    const fields = window.__jobboatDetector.detectFormFields();
    if (fields.length === 0) return; // No fields to fill

    // Show overlay
    createOverlay(fields.length);

    if (!profile) {
      const status = document.querySelector('.jobboat-af-status');
      if (status) {
        status.textContent = 'Connectez-vous sur jobboat.xyz pour commencer';
      }
      const btn = document.querySelector('.jobboat-af-fill');
      if (btn) {
        btn.textContent = 'Non connecte';
        btn.disabled = true;
      }
    }
  }

  // ── Observe DOM changes (for SPAs that load forms dynamically) ──────

  let debounceTimer = null;
  let lastDetectionTime = 0;
  const MIN_REDETECT_INTERVAL = 3000;
  const observer = new MutationObserver((mutations) => {
    // Only react to meaningful DOM changes (new form elements)
    const hasNewInputs = mutations.some(m =>
      Array.from(m.addedNodes).some(n =>
        n.nodeType === 1 && (n.matches?.('input,textarea,select,form') || n.querySelector?.('input,textarea,select'))
      )
    );
    if (!hasNewInputs) return;

    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const now = Date.now();
      if (now - lastDetectionTime < MIN_REDETECT_INTERVAL) return;
      lastDetectionTime = now;
      if (!isOverlayVisible) initDetection();
    }, 1000);
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Start detection
  if (document.readyState === 'complete') {
    setTimeout(initDetection, 1000);
  } else {
    window.addEventListener('load', () => setTimeout(initDetection, 1000));
  }
})();
