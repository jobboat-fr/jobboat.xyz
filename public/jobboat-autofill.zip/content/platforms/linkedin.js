/**
 * JobBoat Auto-Fill — LinkedIn Easy Apply Platform Adapter
 *
 * LinkedIn Easy Apply uses a multi-step modal dialog. Fields use
 * aria-labels and data attributes. This adapter handles detection
 * and filling across steps.
 */

(function () {
  'use strict';

  function isApplicationPage() {
    return (
      document.querySelector('.jobs-apply-button') !== null ||
      document.querySelector('.jobs-easy-apply-modal') !== null ||
      document.querySelector('[data-test-modal-id="easy-apply-modal"]') !== null ||
      document.querySelector('.artdeco-modal--layer-default .jobs-easy-apply-content') !== null
    );
  }

  function getModal() {
    return (
      document.querySelector('.jobs-easy-apply-modal') ||
      document.querySelector('[data-test-modal-id="easy-apply-modal"]') ||
      document.querySelector('.artdeco-modal--layer-default')
    );
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  function fillInputByLabel(container, labelPattern, value) {
    if (!value) return false;
    const labels = container.querySelectorAll('label');
    for (const label of labels) {
      const text = label.textContent.trim();
      if (labelPattern.test(text)) {
        const forId = label.getAttribute('for');
        const input = forId
          ? container.querySelector(`#${CSS.escape(forId)}`)
          : label.querySelector('input, textarea, select');
        if (input && !input.value?.trim()) {
          return setVal(input, value);
        }
      }
    }
    return false;
  }

  async function fill(profile) {
    const modal = getModal() || document;
    let filled = 0;

    // LinkedIn Easy Apply common fields
    const fields = [
      { pattern: /pr[ée]nom|first\s*name/i, value: (profile.name || '').split(/\s+/)[0] || '' },
      { pattern: /nom(\s|$)|last\s*name|family/i, value: (profile.name || '').split(/\s+/).slice(1).join(' ') || '' },
      { pattern: /e[\-\s]?mail/i, value: profile.email || '' },
      { pattern: /t[ée]l[ée]phone|phone|mobile/i, value: profile.phone || '' },
      { pattern: /ville|city|location|localisation/i, value: profile.city || '' },
      { pattern: /linkedin/i, value: profile.linkedin_url || '' },
      { pattern: /site\s*(web)?|portfolio|website/i, value: profile.portfolio_url || '' },
    ];

    for (const { pattern, value } of fields) {
      if (fillInputByLabel(modal, pattern, value)) filled++;
    }

    // Also try direct input selectors for the modal
    const directSelectors = [
      { sel: 'input[name="email"]', value: profile.email },
      { sel: 'input[name="phone"]', value: profile.phone },
      { sel: 'input[type="email"]', value: profile.email },
      { sel: 'input[type="tel"]', value: profile.phone },
    ];

    for (const { sel, value } of directSelectors) {
      if (!value) continue;
      const el = modal.querySelector(sel);
      if (el && !el.value?.trim()) {
        if (setVal(el, value)) filled++;
      }
    }

    return filled;
  }

  window.__jobboatLinkedin = { isApplicationPage, fill };
})();
