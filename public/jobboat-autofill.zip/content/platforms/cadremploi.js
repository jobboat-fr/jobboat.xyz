/**
 * JobBoat Auto-Fill — Cadremploi Platform Adapter
 *
 * Cadremploi is a Figaro Classifieds platform for executive jobs.
 * Application forms use standard naming (prenom, nom, email, telephone, ville).
 */

(function () {
  'use strict';

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('/postuler') ||
      url.includes('/candidature') ||
      url.includes('/annonce/') ||
      document.querySelector('form[class*="apply" i]') !== null ||
      document.querySelector('form[class*="postulation" i]') !== null ||
      document.querySelector('[class*="candidature"]') !== null
    );
  }

  function findInput(patterns, typeHint) {
    for (const pattern of patterns) {
      const el =
        document.querySelector(`input[name*="${pattern}" i]`) ||
        document.querySelector(`input[id*="${pattern}" i]`) ||
        document.querySelector(`input[placeholder*="${pattern}" i]`) ||
        document.querySelector(`textarea[name*="${pattern}" i]`);
      if (el && el.offsetParent !== null) return el;
    }
    if (typeHint) {
      const el = document.querySelector(`input[type="${typeHint}"]`);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  async function fill(profile) {
    let filled = 0;
    const firstName = (profile.name || '').split(/\s+/)[0] || '';
    const lastName = (profile.name || '').split(/\s+/).slice(1).join(' ') || '';

    const fields = [
      { patterns: ['prenom', 'firstname', 'first_name', 'given'], value: firstName },
      { patterns: ['nom', 'lastname', 'last_name', 'family', 'surname'], value: lastName },
      { patterns: ['email', 'mail', 'courriel'], value: profile.email || '', type: 'email' },
      { patterns: ['telephone', 'phone', 'tel', 'mobile', 'portable'], value: profile.phone || '', type: 'tel' },
      { patterns: ['ville', 'city', 'codepostal', 'localisation'], value: profile.city || '' },
      { patterns: ['linkedin'], value: profile.linkedin_url || '' },
      { patterns: ['site', 'portfolio', 'url', 'website'], value: profile.portfolio_url || '' },
    ];

    for (const { patterns, value, type } of fields) {
      if (!value) continue;
      const el = findInput(patterns, type);
      if (el && !el.value?.trim()) {
        if (setVal(el, value)) filled++;
      }
    }

    return filled;
  }

  window.__jobboatCadremploi = { isApplicationPage, fill };
})();
