/**
 * JobBoat Auto-Fill — Indeed.fr / Indeed.com Platform Adapter
 *
 * Indeed uses a multi-step application modal. This adapter detects
 * the current step and fills the appropriate fields.
 */

(function () {
  'use strict';

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('/viewjob') ||
      url.includes('/applystart') ||
      url.includes('/apply') ||
      url.includes('/promo/resume') ||
      document.querySelector('[data-testid="apply-button"]') !== null ||
      document.querySelector('#indeedApplyButton') !== null ||
      document.querySelector('.indeed-apply-button') !== null
    );
  }

  function findFieldBySelectors(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  async function fill(profile) {
    let filled = 0;

    // Indeed apply modal fields (common selectors)
    const fieldMap = [
      {
        selectors: ['#input-firstName', '[name="firstName"]', '[data-testid="first-name-input"]'],
        value: (profile.name || '').split(/\s+/)[0] || '',
      },
      {
        selectors: ['#input-lastName', '[name="lastName"]', '[data-testid="last-name-input"]'],
        value: (profile.name || '').split(/\s+/).slice(1).join(' ') || '',
      },
      {
        selectors: ['#input-email', '[name="email"]', '[data-testid="email-input"]', '[type="email"]'],
        value: profile.email || '',
      },
      {
        selectors: ['#input-phoneNumber', '[name="phoneNumber"]', '[name="phone"]', '[data-testid="phone-input"]', '[type="tel"]'],
        value: profile.phone || '',
      },
      {
        selectors: ['#input-location', '[name="location"]', '[name="city"]', '[data-testid="location-input"]'],
        value: profile.city || '',
      },
      {
        selectors: ['#input-linkedIn', '[name="linkedIn"]', '[name="linkedin"]'],
        value: profile.linkedin_url || '',
      },
    ];

    for (const { selectors, value } of fieldMap) {
      if (!value) continue;
      const el = findFieldBySelectors(selectors);
      if (el && !el.value?.trim()) {
        if (setVal(el, value)) filled++;
      }
    }

    // Indeed "Why are you a good fit?" / cover letter textarea
    const textareas = document.querySelectorAll('textarea');
    for (const ta of textareas) {
      const label = (ta.getAttribute('aria-label') || '').toLowerCase();
      const name = (ta.getAttribute('name') || '').toLowerCase();
      if (label.includes('cover') || label.includes('motivation') || label.includes('message') ||
          name.includes('cover') || name.includes('message')) {
        // Don't auto-fill cover letter — it should be personalized
        continue;
      }
    }

    return filled;
  }

  window.__jobboatIndeed = { isApplicationPage, fill };
})();
