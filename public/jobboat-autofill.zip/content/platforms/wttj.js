/**
 * JobBoat Auto-Fill — Welcome to the Jungle (WTTJ) Platform Adapter
 *
 * WTTJ uses React-based forms with data-testid attributes.
 */

(function () {
  'use strict';

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('/apply') ||
      url.includes('/postuler') ||
      document.querySelector('[data-testid="apply-form"]') !== null ||
      document.querySelector('form[action*="application"]') !== null ||
      document.querySelector('.sc-apply-form') !== null
    );
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  function findByTestId(testId) {
    return document.querySelector(`[data-testid="${testId}"]`);
  }

  function findByNameOrPlaceholder(name, placeholder) {
    return (
      document.querySelector(`input[name="${name}"]`) ||
      document.querySelector(`input[placeholder*="${placeholder}" i]`) ||
      document.querySelector(`textarea[name="${name}"]`)
    );
  }

  async function fill(profile) {
    let filled = 0;
    const firstName = (profile.name || '').split(/\s+/)[0] || '';
    const lastName = (profile.name || '').split(/\s+/).slice(1).join(' ') || '';

    const fieldMap = [
      // WTTJ data-testid based selectors
      { el: findByTestId('apply-field-firstname') || findByNameOrPlaceholder('firstname', 'Prénom'), value: firstName },
      { el: findByTestId('apply-field-lastname') || findByNameOrPlaceholder('lastname', 'Nom'), value: lastName },
      { el: findByTestId('apply-field-email') || findByNameOrPlaceholder('email', 'Email'), value: profile.email || '' },
      { el: findByTestId('apply-field-phone') || findByNameOrPlaceholder('phone', 'Téléphone'), value: profile.phone || '' },
      { el: findByTestId('apply-field-linkedin') || findByNameOrPlaceholder('linkedin', 'LinkedIn'), value: profile.linkedin_url || '' },
      { el: findByTestId('apply-field-portfolio') || findByNameOrPlaceholder('portfolio', 'Portfolio'), value: profile.portfolio_url || '' },
      { el: findByTestId('apply-field-city') || findByNameOrPlaceholder('city', 'Ville'), value: profile.city || '' },
    ];

    for (const { el, value } of fieldMap) {
      if (!el || !value) continue;
      if (el.value?.trim()) continue;
      if (setVal(el, value)) filled++;
    }

    // Also try generic form detection as fallback
    const forms = document.querySelectorAll('form');
    for (const form of forms) {
      const inputs = form.querySelectorAll('input:not([type="hidden"]):not([type="file"]):not([type="submit"]), textarea');
      for (const input of inputs) {
        if (input.getAttribute('data-jobboat-filled')) continue;
        const field = window.__jobboatDetector?.identifyField(input);
        if (field) {
          const value = getValueForType(field.type, profile, firstName, lastName);
          if (value && !input.value?.trim()) {
            if (setVal(input, value)) filled++;
          }
        }
      }
    }

    return filled;
  }

  function getValueForType(type, profile, firstName, lastName) {
    switch (type) {
      case 'firstName': return firstName;
      case 'lastName': return lastName;
      case 'fullName': return profile.name || '';
      case 'email': return profile.email || '';
      case 'phone': return profile.phone || '';
      case 'city': return profile.city || '';
      case 'linkedin': return profile.linkedin_url || '';
      case 'portfolio': return profile.portfolio_url || '';
      default: return '';
    }
  }

  window.__jobboatWttj = { isApplicationPage, fill };
})();
