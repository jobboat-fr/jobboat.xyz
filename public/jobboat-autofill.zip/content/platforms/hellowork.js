/**
 * JobBoat Auto-Fill — HelloWork Platform Adapter
 *
 * HelloWork (formerly RegionsJob) uses standard HTML forms.
 */

(function () {
  'use strict';

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('/postuler') ||
      url.includes('/candidature') ||
      url.includes('/apply') ||
      document.querySelector('form.application-form') !== null ||
      document.querySelector('[class*="apply"]') !== null
    );
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  function findInput(namePatterns, typeHint) {
    for (const pattern of namePatterns) {
      const el =
        document.querySelector(`input[name*="${pattern}" i]`) ||
        document.querySelector(`input[id*="${pattern}" i]`) ||
        document.querySelector(`input[placeholder*="${pattern}" i]`) ||
        document.querySelector(`textarea[name*="${pattern}" i]`);
      if (el && el.offsetParent !== null) return el;
    }
    if (typeHint) {
      const el = document.querySelector(`input[type="${typeHint}"]`);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }

  async function fill(profile) {
    let filled = 0;
    const firstName = (profile.name || '').split(/\s+/)[0] || '';
    const lastName = (profile.name || '').split(/\s+/).slice(1).join(' ') || '';

    const fields = [
      { patterns: ['prenom', 'firstname', 'first_name', 'given'], value: firstName },
      { patterns: ['nom', 'lastname', 'last_name', 'family', 'surname'], value: lastName },
      { patterns: ['email', 'mail', 'courriel'], value: profile.email || '', type: 'email' },
      { patterns: ['phone', 'tel', 'telephone', 'mobile', 'portable'], value: profile.phone || '', type: 'tel' },
      { patterns: ['ville', 'city', 'location', 'lieu'], value: profile.city || '' },
      { patterns: ['linkedin'], value: profile.linkedin_url || '' },
      { patterns: ['site', 'portfolio', 'website', 'url'], value: profile.portfolio_url || '' },
    ];

    for (const { patterns, value, type } of fields) {
      if (!value) continue;
      const el = findInput(patterns, type);
      if (el && !el.value?.trim()) {
        if (setVal(el, value)) filled++;
      }
    }

    return filled;
  }

  window.__jobboatHellowork = { isApplicationPage, fill };
})();
