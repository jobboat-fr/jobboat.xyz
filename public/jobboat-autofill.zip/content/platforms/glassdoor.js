/**
 * JobBoat Auto-Fill — Glassdoor Platform Adapter
 *
 * Glassdoor jobs typically redirect to the employer's ATS (Workday, Greenhouse, etc.)
 * but when apply happens on-site, it uses a React modal.
 */

(function () {
  'use strict';

  function isApplicationPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('/job/') ||
      url.includes('/apply') ||
      url.includes('/partner/jobListing') ||
      document.querySelector('[data-test*="apply" i]') !== null ||
      document.querySelector('form[action*="apply"]') !== null ||
      document.querySelector('button[class*="apply" i]') !== null
    );
  }

  function findInput(patterns, typeHint) {
    for (const pattern of patterns) {
      const el =
        document.querySelector(`input[name*="${pattern}" i]`) ||
        document.querySelector(`input[id*="${pattern}" i]`) ||
        document.querySelector(`input[data-test*="${pattern}" i]`) ||
        document.querySelector(`input[placeholder*="${pattern}" i]`) ||
        document.querySelector(`textarea[name*="${pattern}" i]`);
      if (el && el.offsetParent !== null) return el;
    }
    if (typeHint) {
      const el = document.querySelector(`input[type="${typeHint}"]`);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }

  function setVal(el, value) {
    if (!el || !value) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.setAttribute('data-jobboat-filled', 'true');
    return true;
  }

  async function fill(profile) {
    let filled = 0;
    const firstName = (profile.name || '').split(/\s+/)[0] || '';
    const lastName = (profile.name || '').split(/\s+/).slice(1).join(' ') || '';

    const fields = [
      { patterns: ['firstName', 'first_name', 'first-name', 'prenom', 'given'], value: firstName },
      { patterns: ['lastName', 'last_name', 'last-name', 'nom', 'surname', 'family'], value: lastName },
      { patterns: ['email', 'mail', 'courriel'], value: profile.email || '', type: 'email' },
      { patterns: ['phone', 'telephone', 'tel', 'mobile'], value: profile.phone || '', type: 'tel' },
      { patterns: ['city', 'ville', 'location', 'zip', 'postal'], value: profile.city || '' },
      { patterns: ['linkedin'], value: profile.linkedin_url || '' },
      { patterns: ['website', 'site', 'portfolio', 'url'], value: profile.portfolio_url || '' },
    ];

    for (const { patterns, value, type } of fields) {
      if (!value) continue;
      const el = findInput(patterns, type);
      if (el && !el.value?.trim()) {
        if (setVal(el, value)) filled++;
      }
    }

    return filled;
  }

  window.__jobboatGlassdoor = { isApplicationPage, fill };
})();
