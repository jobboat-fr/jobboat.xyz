# JobBoat Auto-Fill — Chrome Extension

Extension Chrome qui remplit automatiquement les formulaires de candidature sur les portails d'emploi avec votre profil JobBoat.

## Plateformes supportées

| Plateforme | Statut |
|------------|--------|
| Indeed.fr / Indeed.com | ✅ Adapter dédié |
| LinkedIn Easy Apply | ✅ Adapter dédié |
| Welcome to the Jungle | ✅ Adapter dédié |
| HelloWork | ✅ Adapter dédié |
| Glassdoor | 🔄 Détection générique |
| Monster | 🔄 Détection générique |
| APEC | 🔄 Détection générique |
| France Travail | 🔄 Détection générique |
| Cadremploi | 🔄 Détection générique |
| Tout autre site | 🔄 Détection générique |

## Installation (développement)

1. **Générer les icônes** : Ouvrir `icons/generate-icons.html` dans un navigateur, faire clic droit sur chaque canvas → "Enregistrer l'image sous" → `icon-16.png`, `icon-48.png`, `icon-128.png`

2. **Charger l'extension dans Chrome** :
   - Aller à `chrome://extensions/`
   - Activer le **Mode développeur** (en haut à droite)
   - Cliquer **Charger l'extension non empaquetée**
   - Sélectionner le dossier `extension/`

3. **Se connecter** : Se connecter sur `jobboat.xyz` ou `demo.jobboat.xyz` — l'extension capte automatiquement la session Supabase.

4. **Utiliser** : Naviguer vers un portail d'emploi (Indeed, LinkedIn, etc.), ouvrir une offre et cliquer "Postuler". L'overlay JobBoat Auto-Fill apparaîtra avec un bouton **Remplir automatiquement**.

## Architecture

```
extension/
├── manifest.json                 # Manifest V3
├── background/
│   └── service-worker.js         # API calls, session management, caching
├── content/
│   ├── session-bridge.js         # Lit la session Supabase sur jobboat.xyz
│   ├── detector.js               # Détecteur générique de champs de formulaire
│   ├── filler.js                 # Moteur de remplissage + overlay UI
│   ├── overlay.css               # Styles de l'overlay flottant
│   └── platforms/
│       ├── indeed.js             # Adapter Indeed.fr/.com
│       ├── linkedin.js           # Adapter LinkedIn Easy Apply
│       ├── wttj.js               # Adapter Welcome to the Jungle
│       └── hellowork.js          # Adapter HelloWork
├── popup/
│   ├── popup.html                # UI du popup extension
│   ├── popup.css                 # Styles du popup (dark theme JobBoat)
│   └── popup.js                  # Logique du popup
└── icons/
    ├── generate-icons.html       # Générateur d'icônes
    ├── icon-16.png               # (à générer)
    ├── icon-48.png               # (à générer)
    └── icon-128.png              # (à générer)
```

## Flux d'authentification

1. L'utilisateur se connecte sur `jobboat.xyz`
2. `session-bridge.js` lit le token Supabase depuis `localStorage`
3. Le token est envoyé au service worker via `chrome.runtime.sendMessage`
4. Le service worker stocke la session dans `chrome.storage.local`
5. Les content scripts sur les portails d'emploi utilisent la session pour charger le profil

## Champs remplis automatiquement

- Prénom / Nom
- Email
- Téléphone
- Ville
- LinkedIn URL
- Portfolio / Site web
- Disponibilité
- Prétention salariale

> **Note** : La lettre de motivation n'est PAS auto-remplie car elle doit être personnalisée pour chaque poste. Les fichiers (CV) ne peuvent pas être auto-remplis par les extensions Chrome.

## API Backend requise

L'extension utilise l'endpoint existant `GET /api/v2/me` pour récupérer le profil utilisateur. Un nouvel endpoint `POST /api/v2/autoapply/track-portal` est nécessaire pour tracker les candidatures via portail.
