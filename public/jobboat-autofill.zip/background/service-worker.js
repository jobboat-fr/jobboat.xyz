/**
 * JobBoat Auto-Fill — Background Service Worker
 *
 * Handles:
 *  - Session management (receives Supabase token from session-bridge)
 *  - Profile data fetching and caching
 *  - Message routing between popup and content scripts
 */

const API_URLS = [
  'https://api.jobboat.xyz',
  'https://jobboatv1-production-cb89.up.railway.app',
];

function getApiBase() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['apiBase'], (result) => {
      resolve(result.apiBase || API_URLS[0]);
    });
  });
}

async function apiFetch(path, token, options = {}) {
  const base = await getApiBase();
  const url = `${base}${path}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const res = await fetch(url, { ...options, headers });
  if (!res.ok) {
    const err = new Error(`API ${res.status}`);
    err.status = res.status;
    try { err.body = await res.json(); } catch (_) {}
    throw err;
  }
  return res.json();
}

// ── Session storage helpers ──────────────────────────────────────────

async function getSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['session'], (result) => {
      resolve(result.session || null);
    });
  });
}

async function saveSession(session) {
  return chrome.storage.local.set({ session });
}

async function clearSession() {
  return chrome.storage.local.remove(['session', 'profile']);
}

// ── Profile helpers ──────────────────────────────────────────────────

async function getProfile() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['profile', 'profileFetchedAt'], (result) => {
      const age = Date.now() - (result.profileFetchedAt || 0);
      // Cache profile for 10 minutes
      if (result.profile && age < 10 * 60 * 1000) {
        resolve(result.profile);
      } else {
        resolve(null);
      }
    });
  });
}

async function fetchAndCacheProfile() {
  const session = await getSession();
  if (!session?.access_token) return null;

  // Get user email from session (Supabase stores it in user object)
  const userEmail = session.user?.email;
  if (!userEmail) {
    console.warn('[JobBoat Extension] No email in session.user — cannot fetch profile');
    return null;
  }

  try {
    const data = await apiFetch(
      `/api/v2/profile?email=${encodeURIComponent(userEmail)}`,
      session.access_token
    );
    if (data.success && data.profile) {
      const p = data.profile;
      const profile = {
        email: p.email || userEmail,
        name: p.name || p.full_name || '',
        phone: p.phone || p.telephone || '',
        title: p.current_title || p.title || p.job_title || '',
        skills: p.skills || [],
        experience_years: p.experience_years || p.years_experience || null,
        education: p.education || '',
        city: p.city || p.location || p.ville || '',
        linkedin_url: p.linkedin_url || p.linkedin || '',
        portfolio_url: p.portfolio_url || p.website || p.site_web || '',
        summary: p.bio || p.summary || p.about || '',
        availability: p.availability || p.disponibilite || '',
        salary_expectation: p.salary_expectation || p.pretention_salariale || '',
      };
      await chrome.storage.local.set({ profile, profileFetchedAt: Date.now() });
      return profile;
    }
    // Fallback: if no profile in DB, create minimal from session
    const profile = { email: userEmail, name: session.user?.user_metadata?.full_name || session.user?.user_metadata?.name || '' };
    await chrome.storage.local.set({ profile, profileFetchedAt: Date.now() });
    return profile;
  } catch (err) {
    console.warn('[JobBoat Extension] Profile fetch failed:', err.message);
    // Last resort: use session user data
    if (userEmail) {
      const profile = { email: userEmail, name: session.user?.user_metadata?.full_name || '' };
      await chrome.storage.local.set({ profile, profileFetchedAt: Date.now() });
      return profile;
    }
  }
  return null;
}

// ── Active session scanner ───────────────────────────────────────────

const JOBBOAT_URL_PATTERNS = [
  'https://jobboat.xyz/*',
  'https://demo.jobboat.xyz/*',
  'https://*.vercel.app/*',
];

async function scanTabsForSession() {
  try {
    const tabs = await chrome.tabs.query({ url: JOBBOAT_URL_PATTERNS });
    if (!tabs.length) return null;

    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            for (let i = 0; i < localStorage.length; i++) {
              const key = localStorage.key(i);
              if (key && key.startsWith('sb-') && key.endsWith('-auth-token')) {
                try {
                  const raw = localStorage.getItem(key);
                  const parsed = JSON.parse(raw);
                  if (parsed && parsed.access_token) return parsed;
                  if (parsed && parsed.currentSession && parsed.currentSession.access_token) return parsed.currentSession;
                } catch (_) {}
              }
            }
            return null;
          },
        });

        if (results && results[0] && results[0].result) {
          const session = results[0].result;
          await saveSession({
            access_token: session.access_token,
            refresh_token: session.refresh_token || null,
            user: session.user || null,
            expires_at: session.expires_at || null,
          });
          await fetchAndCacheProfile();
          return session;
        }
      } catch (err) {
        console.warn('[JobBoat Extension] Tab scan failed for tab', tab.id, err.message);
      }
    }
  } catch (err) {
    console.warn('[JobBoat Extension] Tab query failed:', err.message);
  }
  return null;
}

// ── Message handler ──────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {
    case 'SESSION_UPDATE': {
      saveSession(payload).then(() => {
        fetchAndCacheProfile().then((profile) => {
          sendResponse({ ok: true, profile });
        });
      });
      return true; // async
    }

    case 'SESSION_CLEAR': {
      clearSession().then(() => sendResponse({ ok: true }));
      return true;
    }

    case 'GET_SESSION': {
      getSession().then((session) => sendResponse({ session }));
      return true;
    }

    case 'CHECK_SESSION': {
      // Actively scan open jobboat tabs for a Supabase session
      (async () => {
        const diag = { tabs_found: 0, tabs_scanned: 0, urls: [], errors: [], keys_found: [] };
        const existing = await getSession();
        if (existing?.access_token) {
          const profile = await getProfile() || await fetchAndCacheProfile();
          sendResponse({ session: existing, profile, diag: { ...diag, source: 'cached' } });
          return;
        }
        try {
          const tabs = await chrome.tabs.query({ url: JOBBOAT_URL_PATTERNS });
          diag.tabs_found = tabs.length;
          diag.urls = tabs.map(t => t.url);

          for (const tab of tabs) {
            if (!tab.id) continue;
            diag.tabs_scanned++;
            try {
              const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                  const info = { keys: [], session: null };
                  for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    if (key) info.keys.push(key);
                    if (key && key.startsWith('sb-') && key.endsWith('-auth-token')) {
                      try {
                        const raw = localStorage.getItem(key);
                        const parsed = JSON.parse(raw);
                        if (parsed && parsed.access_token) { info.session = parsed; break; }
                        if (parsed && parsed.currentSession && parsed.currentSession.access_token) {
                          info.session = parsed.currentSession; break;
                        }
                      } catch (_) {}
                    }
                  }
                  return info;
                },
              });

              if (results && results[0] && results[0].result) {
                const { keys, session } = results[0].result;
                diag.keys_found = keys.filter(k => k.startsWith('sb-'));
                if (session) {
                  await saveSession({
                    access_token: session.access_token,
                    refresh_token: session.refresh_token || null,
                    user: session.user || null,
                    expires_at: session.expires_at || null,
                  });
                  const profile = await fetchAndCacheProfile();
                  sendResponse({ session, profile, diag: { ...diag, source: 'tab_scan' } });
                  return;
                }
              }
            } catch (err) {
              diag.errors.push(`Tab ${tab.id}: ${err.message}`);
            }
          }
        } catch (err) {
          diag.errors.push(`Query: ${err.message}`);
        }
        sendResponse({ session: null, profile: null, diag });
      })();
      return true;
    }

    case 'GET_PROFILE': {
      getProfile().then(async (cached) => {
        if (cached) return sendResponse({ profile: cached });
        const fresh = await fetchAndCacheProfile();
        sendResponse({ profile: fresh });
      });
      return true;
    }

    case 'REFRESH_PROFILE': {
      fetchAndCacheProfile().then((profile) => sendResponse({ profile }));
      return true;
    }

    case 'AI_DETECT_FIELDS': {
      // Send DOM snapshot to backend for Anthropic Claude AI analysis
      (async () => {
        const session = await getSession();
        if (!session?.access_token) {
          sendResponse({ success: false, error: 'not_authenticated', mappings: [] });
          return;
        }
        try {
          const data = await apiFetch('/api/v2/autofill/ai-detect', session.access_token, {
            method: 'POST',
            body: JSON.stringify({ elements: payload.elements }),
          });
          sendResponse({ success: data.success, mappings: data.mappings || [], model: data.model || null });
        } catch (err) {
          console.warn('[JobBoat Extension] AI detect failed:', err.message);
          sendResponse({ success: false, error: err.message, mappings: [] });
        }
      })();
      return true;
    }

    case 'TRACK_APPLICATION': {
      // Fire-and-forget tracking to JobBoat backend
      getSession().then(async (session) => {
        if (!session?.access_token) return sendResponse({ ok: false });
        try {
          await apiFetch('/api/v2/autoapply/track-portal', session.access_token, {
            method: 'POST',
            body: JSON.stringify(payload),
          });
          sendResponse({ ok: true });
        } catch (_) {
          sendResponse({ ok: false });
        }
      });
      return true;
    }

    case 'TRACK_AUTOFILL_TELEMETRY': {
      // Fire-and-forget telemetry for autofill success measurement.
      // Works even when not authenticated (server accepts anonymous records).
      (async () => {
        try {
          const session = await getSession();
          const manifest = chrome.runtime.getManifest();
          const body = { ...payload, extension_version: manifest.version };
          await apiFetch('/api/v2/autofill/telemetry', session?.access_token || null, {
            method: 'POST',
            body: JSON.stringify(body),
          });
          sendResponse({ ok: true });
        } catch (err) {
          // Never fail loudly — telemetry is best-effort
          sendResponse({ ok: false, error: err.message });
        }
      })();
      return true;
    }

    default:
      sendResponse({ error: 'unknown_message_type' });
  }
});

// ── Auto-check session on extension install/startup ─────────────────

chrome.runtime.onInstalled.addListener(() => {
  scanTabsForSession();
});

chrome.runtime.onStartup.addListener(() => {
  scanTabsForSession();
});

// ── Badge update on session change ───────────────────────────────────

chrome.storage.onChanged.addListener((changes) => {
  if (changes.session) {
    const session = changes.session.newValue;
    if (session?.access_token) {
      chrome.action.setBadgeText({ text: '' });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    } else {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    }
  }
});
