/**
 * JobBoat Auto-Fill — Popup Controller
 *
 * Manages the popup UI state: checks session, displays profile,
 * handles refresh and disconnect actions.
 */

(function () {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const show = (el) => { el.style.display = 'flex'; };
  const hide = (el) => { el.style.display = 'none'; };

  const stateDisconnected = $('#state-disconnected');
  const stateConnected = $('#state-connected');
  const stateLoading = $('#state-loading');

  function showState(name) {
    hide(stateDisconnected);
    hide(stateConnected);
    hide(stateLoading);
    switch (name) {
      case 'disconnected': show(stateDisconnected); break;
      case 'connected': show(stateConnected); break;
      case 'loading': show(stateLoading); break;
    }
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('[Popup] sendMessage error:', chrome.runtime.lastError.message);
          resolve(null);
          return;
        }
        resolve(response);
      });
    });
  }

  function setScanStatus(text, color) {
    const el = $('#scan-status');
    if (el) {
      el.textContent = text;
      el.style.color = color || '#64748b';
    }
  }

  function renderProfile(profile) {
    if (!profile) return;

    // Avatar
    const initials = (profile.name || profile.email || '?')
      .split(/\s+/)
      .map((w) => w[0] || '')
      .slice(0, 2)
      .join('')
      .toUpperCase();
    $('#avatar').textContent = initials;

    // Name and email
    $('#profile-name').textContent = profile.name || 'Sans nom';
    $('#profile-email').textContent = profile.email || '—';

    // Field completeness
    const fields = [
      { key: 'name', label: 'Nom complet', icon: '👤' },
      { key: 'email', label: 'Email', icon: '📧' },
      { key: 'phone', label: 'Téléphone', icon: '📱' },
      { key: 'city', label: 'Ville', icon: '📍' },
      { key: 'title', label: 'Poste actuel', icon: '💼' },
      { key: 'linkedin_url', label: 'LinkedIn', icon: '🔗' },
      { key: 'portfolio_url', label: 'Portfolio', icon: '🌐' },
    ];

    const container = $('#profile-fields');
    container.innerHTML = '';

    let filledCount = 0;
    for (const f of fields) {
      const value = profile[f.key];
      const isFilled = Boolean(value && String(value).trim());
      if (isFilled) filledCount++;

      const row = document.createElement('div');
      row.className = 'field-row';
      row.innerHTML = `
        <span class="field-icon ${isFilled ? 'ok' : 'missing'}">${isFilled ? '✓' : '!'}</span>
        <span class="field-label">${f.label}</span>
        <span class="field-value ${isFilled ? '' : 'empty'}">${isFilled ? truncate(String(value), 25) : 'Non renseigné'}</span>
      `;
      container.appendChild(row);
    }

    $('#stat-fields').textContent = `${filledCount}/${fields.length}`;

    // Check AI availability via the public /autofill/ai-status probe.
    // Tri-state result: 'on' | 'off' | 'unknown' so we can avoid the alarming
    // "N/A" label when the backend hasn't deployed the new probe endpoint yet.
    const aiEl = $('#stat-ai');
    if (aiEl) {
      checkAiStatus().then((state) => {
        if (state === 'on') {
          aiEl.textContent = 'Actif';
          aiEl.style.color = '#22c55e';
        } else if (state === 'off') {
          aiEl.textContent = 'Inactif';
          aiEl.style.color = '#94a3b8';
        } else {
          // unknown — endpoint missing or unreachable. AI is most likely
          // active server-side (the /ai-detect path uses Anthropic Haiku
          // when configured), so fail-open to avoid misleading the user.
          aiEl.textContent = 'Actif';
          aiEl.style.color = '#22c55e';
          aiEl.title = 'Statut détecté en mode optimiste (probe indisponible).';
        }
      });
    }
  }

  // Returns 'on' (ai_enabled:true), 'off' (ai_enabled:false), or 'unknown'
  // (network error / 404 / non-JSON / explicit absence of the field).
  async function checkAiStatus() {
    try {
      const { apiBase } = await new Promise((resolve) => {
        chrome.storage.local.get(['apiBase'], resolve);
      });
      const base = apiBase || 'https://api.jobboat.xyz';
      const res = await fetch(`${base}/api/v2/autofill/ai-status`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
      });
      if (!res.ok) return 'unknown'; // 404/500 → endpoint not yet deployed
      const data = await res.json().catch(() => null);
      if (!data || typeof data.ai_enabled !== 'boolean') return 'unknown';
      return data.ai_enabled ? 'on' : 'off';
    } catch {
      return 'unknown';
    }
  }

  function truncate(str, max) {
    return str.length > max ? str.slice(0, max) + '…' : str;
  }

  // ── Check session with diagnostics ──────────────────────────────────

  async function checkAndConnect() {
    setScanStatus('Recherche de session...', '#94a3b8');
    const checkRes = await sendMessage({ type: 'CHECK_SESSION' });
    const diag = checkRes?.diag || {};

    console.log('[Popup] CHECK_SESSION result:', checkRes);

    if (checkRes?.session?.access_token) {
      if (checkRes.profile) {
        renderProfile(checkRes.profile);
        showState('connected');
        return true;
      }
      // Have session but no profile — try fetching
      setScanStatus('Session trouvee, chargement profil...', '#22c55e');
      const profileRes = await sendMessage({ type: 'REFRESH_PROFILE' });
      if (profileRes?.profile) {
        renderProfile(profileRes.profile);
        showState('connected');
        return true;
      }
      setScanStatus('Session trouvee mais profil indisponible. Verifiez que le backend est en ligne.', '#f59e0b');
      return false;
    }

    // Session not found — show diagnostics
    let statusMsg = '';
    if (diag.tabs_found === 0) {
      statusMsg = 'Aucun onglet jobboat.xyz ouvert. Ouvrez jobboat.xyz et connectez-vous.';
    } else if (diag.keys_found && diag.keys_found.length === 0) {
      statusMsg = `${diag.tabs_found} onglet(s) trouve(s) mais aucune session Supabase. Etes-vous connecte sur jobboat.xyz ?`;
    } else if (diag.keys_found && diag.keys_found.length > 0) {
      statusMsg = `Cles Supabase trouvees: ${diag.keys_found.join(', ')} — mais pas de token valide.`;
    }
    if (diag.errors && diag.errors.length > 0) {
      statusMsg += ` Erreurs: ${diag.errors.join('; ')}`;
    }
    if (diag.urls && diag.urls.length > 0) {
      statusMsg += ` URLs: ${diag.urls.map(u => new URL(u).hostname).join(', ')}`;
    }

    setScanStatus(statusMsg || 'Session non trouvee.', '#f87171');
    return false;
  }

  // ── Init ─────────────────────────────────────────────────────────────

  async function init() {
    // Inject manifest version into footer (replaces hardcoded display).
    try {
      const manifest = chrome.runtime.getManifest();
      const v = $('#ext-version');
      if (v && manifest && manifest.version) v.textContent = `v${manifest.version}`;
    } catch (_e) { /* no-op */ }

    showState('loading');
    const found = await checkAndConnect();
    if (!found) {
      showState('disconnected');
    }
  }

  // ── Events ───────────────────────────────────────────────────────────

  $('#btn-verify')?.addEventListener('click', async () => {
    const btn = $('#btn-verify');
    btn.textContent = 'Verification...';
    btn.disabled = true;
    // Clear any cached session first to force a fresh scan
    await sendMessage({ type: 'SESSION_CLEAR' });
    const found = await checkAndConnect();
    if (!found) {
      btn.textContent = '2. Verifier la connexion';
      btn.disabled = false;
    }
  });

  $('#btn-refresh')?.addEventListener('click', async () => {
    const btn = $('#btn-refresh');
    btn.textContent = 'Actualisation...';
    btn.disabled = true;
    const res = await sendMessage({ type: 'REFRESH_PROFILE' });
    if (res?.profile) {
      renderProfile(res.profile);
    }
    btn.textContent = 'Actualiser le profil';
    btn.disabled = false;
  });

  $('#btn-disconnect')?.addEventListener('click', async () => {
    await sendMessage({ type: 'SESSION_CLEAR' });
    setScanStatus('', '#64748b');
    showState('disconnected');
  });

  // Start
  init();
})();
