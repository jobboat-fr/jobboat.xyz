# JobBoat Auto-Fill — Chrome Web Store Publishing Guide

## Pre-requisites Checklist

- [x] Extension source code complete (manifest.json, background, content, popup, icons)
- [x] ZIP built: `extension/dist/jobboat-autofill-v1.0.0.zip` (48.7 KB)
- [x] Store description: `extension/store/description.txt`
- [x] Privacy policy HTML: `extension/store/privacy-policy.html`
- [x] Privacy policy hosted: `https://jobboat.xyz/privacy-extension.html` (deploy frontend to activate)
- [ ] Screenshots (generate from `extension/store/generate-screenshots.html`)

---

## Step 1: Generate Screenshots

1. Open `extension/store/generate-screenshots.html` in Chrome
2. Click the **Download PNG** button under each image:
   - `screenshot-1-hero.png` (1280×800) — **Required**
   - `screenshot-2-popup.png` (1280×800)
   - `screenshot-3-platforms.png` (1280×800)
   - `screenshot-4-fields.png` (1280×800)
   - `promo-tile-440x280.png` (440×280) — Recommended
   - `marquee-promo-1400x560.png` (1400×560) — Optional
3. Save them in `extension/store/` folder

---

## Step 2: Chrome Developer Account

1. Go to https://chrome.google.com/webstore/devconsole
2. Sign in with your Google account
3. If first time: Pay the **$5 USD** one-time developer registration fee
4. Complete identity verification (may take 1-3 business days)

---

## Step 3: Deploy Privacy Policy

Before submitting, the privacy policy must be accessible at a public URL.

**Option A — Via Vercel (recommended):**
The file is already at `frontend/public/privacy-extension.html`.
After your next Vercel deployment, it will be live at:
```
https://jobboat.xyz/privacy-extension.html
```

**Option B — Quick deploy now:**
```bash
cd frontend && npx vercel --prod
```

---

## Step 4: Submit to Chrome Web Store

1. Go to https://chrome.google.com/webstore/devconsole
2. Click **"New Item"** (top-right blue button)
3. Upload the ZIP: `extension/dist/jobboat-autofill-v1.0.0.zip`
4. Fill in the **Store Listing** tab:

### Store Listing
| Field | Value |
|-------|-------|
| **Language** | French (fr) |
| **Title** | JobBoat Auto-Fill |
| **Summary** | Remplissez automatiquement vos candidatures sur les portails d'emploi avec votre profil JobBoat. |
| **Description** | Copy from `extension/store/description.txt` |
| **Category** | Productivity |
| **Screenshots** | Upload the 4 screenshots (1280×800) |
| **Promo tile** | Upload `promo-tile-440x280.png` (Small) |
| **Marquee** | Upload `marquee-promo-1400x560.png` (Large, optional) |

### Privacy Tab
| Field | Value |
|-------|-------|
| **Single purpose** | "Auto-fill job application forms on job portals with user's JobBoat profile data" |
| **Permission justifications** | See below |
| **Privacy policy URL** | `https://jobboat.xyz/privacy-extension.html` |
| **Data use disclosures** | See below |

#### Permission Justifications
| Permission | Justification |
|------------|---------------|
| `activeTab` | To detect and fill form fields on the currently active job portal page |
| `storage` | To cache the user's authentication session and profile data locally |
| `scripting` | To read the Supabase authentication token from an open jobboat.xyz tab |
| `tabs` | To find an open jobboat.xyz tab for session bridge authentication |
| Host permissions (job sites) | To inject content scripts that detect form fields on supported job portals |
| Host permissions (jobboat.xyz) | To read authentication tokens and communicate with the JobBoat API |

#### Data Use Disclosures
- **Personal data collected**: Authentication tokens (for API access), profile data (name, email, phone, city)
- **Stored locally**: Yes, via `chrome.storage.local`
- **Transmitted**: Only to `api.jobboat.xyz` (first-party API)
- **NOT sold to third parties**: Correct
- **NOT used for advertising**: Correct
- **NOT used for creditworthiness**: Correct

### Distribution Tab
| Field | Value |
|-------|-------|
| **Visibility** | Public |
| **Distribution** | All regions (or limit to France if desired) |

5. Click **"Submit for Review"**

---

## Step 5: Review Process

- Google reviews typically take **1-3 business days** (can be up to 7 for first submissions)
- You'll receive an email at your Google account when approved or if changes are needed
- Common rejection reasons:
  - Privacy policy URL not accessible
  - Permission justifications too vague
  - Screenshots not matching actual functionality
  - Host permissions too broad (yours are specific — should be fine)

---

## Step 6: Post-Publish

After approval:
1. Your extension will be live at: `https://chrome.google.com/webstore/detail/jobboat-auto-fill/{extension-id}`
2. Add a link on jobboat.xyz pointing to the Chrome Web Store listing
3. The self-hosted ZIP is also available at `https://jobboat.xyz/jobboat-autofill.zip` for sideloading

### Updating the Extension
1. Bump version in `manifest.json` (e.g., `1.0.1`)
2. Run `node extension/build-zip.js` to rebuild the ZIP
3. Go to Chrome Developer Dashboard → your extension → **Package** tab
4. Click **Upload updated package** and upload the new ZIP
5. Submit for review again

---

## Firefox Add-ons (Optional — Future)

The extension uses Manifest V3 which Firefox now supports. To publish on Firefox:
1. Go to https://addons.mozilla.org/developers/
2. Create a developer account (free)
3. Upload the same ZIP
4. Firefox review is typically faster (24-48 hours)

Note: You may need minor manifest changes for full Firefox compatibility.
