/**
 * Auto-generate Chrome Web Store screenshots from generate-screenshots.html.
 *
 * Uses puppeteer-core against the system Chrome (no big chromium download).
 *
 * Run from repo root:
 *   node extension/store/generate-screenshots.js
 *
 * Outputs the following PNGs into extension/store/:
 *   - screenshot-1-hero.png      (1280x800)
 *   - screenshot-2-popup.png     (1280x800)
 *   - screenshot-3-platforms.png (1280x800)
 *   - screenshot-4-fields.png    (1280x800)
 *   - promo-tile-440x280.png     (440x280)
 *   - marquee-promo-1400x560.png (1400x560)
 */

const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const CHROME_CANDIDATES = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  process.env.LOCALAPPDATA
    ? path.join(process.env.LOCALAPPDATA, 'Google\\Chrome\\Application\\chrome.exe')
    : null,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
].filter(Boolean);

const TARGETS = [
  { id: 'ss1', file: 'screenshot-1-hero.png' },
  { id: 'ss2', file: 'screenshot-2-popup.png' },
  { id: 'ss3', file: 'screenshot-3-platforms.png' },
  { id: 'ss4', file: 'screenshot-4-fields.png' },
  { id: 'promo', file: 'promo-tile-440x280.png' },
  { id: 'marquee', file: 'marquee-promo-1400x560.png' },
];

function findChrome() {
  for (const p of CHROME_CANDIDATES) {
    if (p && fs.existsSync(p)) return p;
  }
  throw new Error(
    'Chrome not found. Set CHROME_PATH env var to your chrome.exe (or chromium binary).'
  );
}

async function main() {
  let puppeteer;
  try {
    puppeteer = require('puppeteer-core');
  } catch {
    console.error(
      '\npuppeteer-core not installed. Run from repo root:\n  npm install --no-save puppeteer-core\n'
    );
    process.exit(1);
  }

  const chromePath = process.env.CHROME_PATH || findChrome();
  const htmlPath = path.join(__dirname, 'generate-screenshots.html');
  const outDir = __dirname;
  const url = pathToFileURL(htmlPath).href;

  console.log(`[generate-screenshots] Chrome: ${chromePath}`);
  console.log(`[generate-screenshots] URL:    ${url}`);
  console.log(`[generate-screenshots] Output: ${outDir}`);

  const browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1600, height: 1200, deviceScaleFactor: 1 });
    await page.goto(url, { waitUntil: 'networkidle0' });
    // Give the IIFE drawing routines a moment to fully paint each canvas.
    await new Promise((r) => setTimeout(r, 800));

    for (const { id, file } of TARGETS) {
      const dataUrl = await page.evaluate((canvasId) => {
        const c = document.getElementById(canvasId);
        if (!c) return null;
        return c.toDataURL('image/png');
      }, id);

      if (!dataUrl) {
        console.error(`  ✗ canvas #${id} not found, skipping ${file}`);
        continue;
      }

      const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
      const outPath = path.join(outDir, file);
      fs.writeFileSync(outPath, Buffer.from(base64, 'base64'));
      const { size } = fs.statSync(outPath);
      console.log(`  ✓ ${file} (${(size / 1024).toFixed(1)} KB)`);
    }
  } finally {
    await browser.close();
  }

  console.log('\nDone. Upload these PNGs to the Chrome Web Store listing.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
